remove dots from email id's, and hide the domain.

Connect directly to db??
