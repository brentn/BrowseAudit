save to local storage

provide a summary page
